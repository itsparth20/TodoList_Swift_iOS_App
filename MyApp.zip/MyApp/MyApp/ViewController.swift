//
//  ViewController.swift
//  MyApp
//
//  Created by Parth Patel on 9/18/16.
//  Copyright © 2016 Parth Parth. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    //var item:String = String();
    var item = Item?()
    
    @IBOutlet weak var nameTextField: UITextField!
    @IBOutlet weak var nameLabel: UILabel!
    
    @IBOutlet weak var saveButton: UIBarButtonItem!
    @IBAction func cancel(sender: UIBarButtonItem) {
        let isInAddMode = presentingViewController is UINavigationController
        
        if isInAddMode {
            dismissViewControllerAnimated(true, completion: nil)
        }
        else {
            navigationController!.popViewControllerAnimated(true)
        }
    }
    
    
    @IBAction func setTextLabel(sender: UIButton) {
        nameLabel.text = nameTextField.text
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        
        
        if let item = item {
            nameTextField.text   = item.name
        }
        
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    /*
    override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
        if segue.identifier == "SaveEditItem" {
            let itemTableViewCon = segue.destinationViewController as! ItemTableViewController
            
            itemTableViewCon.itemForSaveEdit = nameTextField.text!;
            }
        
    
    }*/
    
    override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
        if saveButton === sender {
            let name = nameTextField.text ?? ""
            item = Item(name: name)
        }
    }

}

